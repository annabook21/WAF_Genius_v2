const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { Reader } = require('@maxmind/geoip2-node');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS for the development frontend
app.use(cors());
app.use(express.json());

// Initialize the MaxMind reader
let geoReader = null;
const dbPath = path.resolve('./GeoLite2-City.mmdb');

try {
  if (fs.existsSync(dbPath)) {
    const dbBuffer = fs.readFileSync(dbPath);
    geoReader = Reader.openBuffer(dbBuffer);
    console.log('MaxMind GeoLite2 database loaded successfully');
  } else {
    console.error('GeoLite2 database not found:', dbPath);
  }
} catch (error) {
  console.error('Error loading GeoLite2 database:', error);
}

// Endpoint to check if the database is available
app.get('/api/geo/status', (req, res) => {
  if (geoReader) {
    const stats = fs.statSync(dbPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(1);
    
    res.json({
      available: true,
      size: fileSizeMB
    });
  } else {
    res.json({
      available: false,
      size: 0
    });
  }
});

// Endpoint to look up IPs
app.post('/api/geo/lookup', (req, res) => {
  const { ips } = req.body;
  
  if (!ips || !Array.isArray(ips)) {
    return res.status(400).json({ error: 'Invalid request. Expected array of IPs' });
  }
  
  if (!geoReader) {
    return res.status(503).json({ 
      error: 'GeoLite2 database not available',
      useMock: true 
    });
  }
  
  const results = {};
  
  for (const ip of ips) {
    try {
      const response = geoReader.city(ip);
      results[ip] = {
        country: response.country?.isoCode || 'Unknown',
        city: response.city?.names?.en || 'Unknown'
      };
    } catch (err) {
      results[ip] = { country: 'Unknown', city: 'Unknown' };
    }
  }
  
  res.json({ results });
});

// Also serve static files from public directory
app.use(express.static('public'));

app.listen(PORT, () => {
  console.log(`Geo API server running on port ${PORT}`);
}); 