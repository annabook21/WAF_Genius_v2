
import React from 'react';
import Header from './Header';

interface PageWrapperProps {
  children: React.ReactNode;
}

const PageWrapper = ({ children }: PageWrapperProps) => {
  return (
    <div className="min-h-screen flex flex-col bg-cyber-black text-white">
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <footer className="p-2 text-center text-xs text-cyber-gray border-t border-cyber-green/30">
        <p>WAF-Log-Parody-Inspector © {new Date().getFullYear()} • CAUTION: For Educational Use Only</p>
        <p className="text-[10px] text-cyber-red/70">This software is intended to highlight malicious code patterns.</p>
      </footer>
    </div>
  );
};

export default PageWrapper;
